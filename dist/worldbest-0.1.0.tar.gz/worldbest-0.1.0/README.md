# WorldBest

Small, buildable Python package with a CLI. Use it as a starting point.

## Quick start

1. Create/activate a Python 3.10+ environment.

1. Install dev tools (pytest and build):

```bash
pip install -U pip
pip install pytest build
```

1. Run tests:

```bash
pytest -q
```

1. Build sdist and wheel into `dist/`:

```bash
python -m build
```

1. Try the CLI (without installing):

```bash
python -m worldbest.cli Alice
```

Or, after installing locally:

```bash
pip install -e .
worldbest Bob
```

## Project layout

- `pyproject.toml` — build and project metadata (PEP 621)
- `src/worldbest/` — package source
- `tests/` — pytest tests

## License

MIT
